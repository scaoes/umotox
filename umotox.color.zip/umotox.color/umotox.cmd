@echo off
setlocal enabledelayedexpansion

:: Enable ANSI colors
for /f %%A in ('echo prompt $E ^| cmd') do set "ESC=%%A"
set "RED=%ESC%[31m"
set "GREEN=%ESC%[32m"
set "BLUE=%ESC%[34m"
set "YELLOW=%ESC%[93m"
set "RESET=%ESC%[0m"

echo.
echo ========================================
echo     %YELLOW%UMOTOX - WAV / MP3 to BCWAV%RESET%
echo ========================================
echo.

:: Create output folder if missing
if not exist "output" (
    mkdir "output"
)

if not exist "tools\\ffmpeg.exe" (
    echo %RED%ERROR:%RESET% ffmpeg.exe is missing in the %BLUE%tools%RESET% folder.
    pause
    exit /b
)

if not exist "tools\\ctr_WaveConverter32.exe" (
    echo %RED%ERROR:%RESET% ctr_WaveConverter32.exe is missing in the %BLUE%tools%RESET% folder.
    pause
    exit /b
)

if "%~1"=="" (
    echo No files dropped. Processing all %BLUE%.mp3%RESET% and %BLUE%.wav%RESET% files in folder...
    for %%f in (*.mp3 *.wav) do call :convert "%%f"
) else (
    :loop
    if "%~1"=="" goto done
    call :convert "%~1"
    shift
    goto loop
)

:done
echo.
echo %GREEN%Done!%RESET% All BCWAV files are in the %BLUE%'output'%RESET% folder.
echo Location: %BLUE%%CD%\output%RESET%
pause
exit /b

:convert
set "input=%~1"
set "name=%~n1"
set "ext=%~x1"
set "wavfile=!name!.wav"
set "bcwavfile=output\\!name!.bcwav"

echo Converting: %BLUE%!input!%RESET%

if /I "!ext!"==".mp3" (
    echo Using %BLUE%ffmpeg%RESET% to convert MP3 to WAV...
    tools\\ffmpeg.exe -i "!input!" -ar 44100 -ac 2 "!wavfile!" -y >nul 2>&1
    if errorlevel 1 (
        echo %RED%ERROR:%RESET% ffmpeg failed to convert %BLUE%!input!%RESET%.
        pause
        exit /b
    )
) else (
    copy "!input!" "!wavfile!" >nul
)

if exist "!wavfile!" (
    echo Running %BLUE%ctr_WaveConverter32.exe%RESET% to convert WAV to BCWAV...
    tools\\ctr_WaveConverter32.exe --pcm16 "!wavfile!" -o "!bcwavfile!" >>debug_log.txt 2>&1
    if exist "!bcwavfile!" (
        del "!wavfile!"
        echo %GREEN%Success:%RESET% Converted file is located in: %BLUE%%CD%\output%RESET%
    ) else (
        echo %RED%ERROR:%RESET% Conversion to BCWAV failed for %BLUE%!input!%RESET%. Check debug_log.txt for details.
        pause
    )
) else (
    echo %RED%ERROR:%RESET% Failed to convert %BLUE%!input!%RESET% to WAV.
)

