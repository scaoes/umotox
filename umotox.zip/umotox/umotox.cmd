@echo off
setlocal enabledelayedexpansion

echo.
echo ========================================
echo     UMOTOX - WAV / MP3 to BCWAV
echo ========================================
echo.

:: Create output folder if missing
if not exist "output" (
    mkdir "output"
)

:: Check for ffmpeg
if not exist "tools\\ffmpeg.exe" (
    echo ERROR: ffmpeg.exe is missing in the tools folder.
    pause
    exit /b
)

:: Check for ctr_WaveConverter32
if not exist "tools\\ctr_WaveConverter32.exe" (
    echo ERROR: ctr_WaveConverter32.exe is missing in the tools folder.
    pause
    exit /b
)

:: Handle files
if "%~1"=="" (
    echo No files dropped. Processing all .mp3 and .wav files in folder...
    for %%f in (*.mp3 *.wav) do call :convert "%%f"
) else (
    :loop
    if "%~1"=="" goto done
    call :convert "%~1"
    shift
    goto loop
)

:done
echo.
echo Done! All BCWAV files are in the 'output' folder.
echo Location: %CD%\output
pause
exit /b

:convert
set "input=%~1"
set "name=%~n1"
set "ext=%~x1"
set "wavfile=!name!.wav"
set "bcwavfile=output\\!name!.bcwav"

echo Converting: !input!

:: Convert MP3 to WAV if needed
if /I "!ext!"==".mp3" (
    echo Using ffmpeg to convert MP3 to WAV...
    tools\\ffmpeg.exe -i "!input!" -ar 44100 -ac 2 "!wavfile!" -y >nul 2>&1
    if errorlevel 1 (
        echo ERROR: ffmpeg failed to convert !input! to WAV.
        pause
        exit /b
    )
) else (
    copy "!input!" "!wavfile!" >nul
)

:: Convert WAV to BCWAV
if exist "!wavfile!" (
    echo Running ctr_WaveConverter32.exe to convert WAV to BCWAV...
    tools\\ctr_WaveConverter32.exe --pcm16 "!wavfile!" -o "!bcwavfile!" >>debug_log.txt 2>&1
    if exist "!bcwavfile!" (
        del "!wavfile!"
        echo Success: Converted file is located in: %CD%\output
    ) else (
        echo ERROR: Conversion to BCWAV failed for !input!. Check debug_log.txt for details.
        pause
    )
) else (
    echo ERROR: Failed to convert !input! to WAV.
)
